package ca.georgebrown.comp2074.myportfolio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button profSum = (Button) findViewById(R.id.btn_prof_sum);
        profSum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(),Professional_summary.class);
                startActivity(i);
                finish();
            }
        });

        button = (Button) findViewById((R.id.btn_resume));
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openResume();
            }
        });

        Button academicCredit = (Button) findViewById(R.id.btn_academic);
        academicCredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(),AcademicCredentials.class);
                startActivity(i);
                finish();
            }
        });

        Button capsSum = (Button) findViewById(R.id.btn_caps);
        capsSum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(),capstone_summery.class);
                startActivity(i);
                finish();
            }
        });
    }

    public void openResume(){
        Intent intent = new Intent(this, Sahara_Resume.class);
        startActivity(intent);
    }
}
