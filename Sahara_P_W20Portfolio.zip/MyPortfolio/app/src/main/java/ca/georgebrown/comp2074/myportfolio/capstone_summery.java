package ca.georgebrown.comp2074.myportfolio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class capstone_summery extends AppCompatActivity {

    private Button home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capstone_summery);
        home = (Button) findViewById(R.id.btn_home6);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        Button immunSumm = findViewById(R.id.btn_capstoneSum);
        immunSumm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), caps_project_summ.class);
                startActivity(i);
                finish();
            }
        });

        Button projectMockup = findViewById(R.id.btn_capstone_mock);
        projectMockup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), caps_project_mockup.class);
                startActivity(i);
                finish();
            }
        });
        Button academicWork = findViewById(R.id.btn_capstone_github);
        academicWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // link to Github page for Sahara's academic work
                Uri link = Uri.parse("https://github.com/tcarlberg37/immunizationtario");
                Intent i = new Intent(Intent.ACTION_VIEW, link);
                startActivity(i);
            }
        });
    }
}
