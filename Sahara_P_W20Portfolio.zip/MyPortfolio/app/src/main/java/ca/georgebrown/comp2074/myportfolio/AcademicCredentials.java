package ca.georgebrown.comp2074.myportfolio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AcademicCredentials extends AppCompatActivity {
    private Button academicRewards;
    private Button transcript;
    private Button home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_academic_credentials);

        home = (Button) findViewById(R.id.btn_home3);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), MainActivity.class);
                startActivity(i);
                finish();
            }
        });

        academicRewards = (Button) findViewById(R.id.academicAward);
        academicRewards.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(),academic_awards.class);
                startActivity(i);
                finish();
            }
        });

        transcript = (Button) findViewById(R.id.transcript);
        transcript.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), sahara_transcript.class);
                startActivity(i);
                finish();
            }
        });

        Button academicWork = findViewById(R.id.academicWork);
        academicWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // link to Github page for Sahara's academic work
                Uri link = Uri.parse("https://github.com/saharapanna?tab=repositories");
                Intent i = new Intent(Intent.ACTION_VIEW, link);
                startActivity(i);
            }
        });
    }

}
